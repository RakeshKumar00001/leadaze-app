import { Check, ArrowRight, Instagram, Youtube, Twitch, MessageSquare } from "lucide-react";
import { Link } from "react-router";

const services = [
  {
    title: "Influencer Campaign Management",
    description: "End-to-end campaign management from strategy to execution and reporting.",
    features: [
      "Campaign strategy development",
      "Influencer sourcing and vetting",
      "Contract negotiation and management",
      "Content approval and optimization",
      "Performance tracking and analytics",
      "ROI reporting and insights"
    ],
    icon: Instagram,
    gradient: "from-pink-500 to-rose-500"
  },
  {
    title: "Content Creation Services",
    description: "Professional content creation that aligns with your brand and resonates with your audience.",
    features: [
      "Brand-aligned content strategy",
      "Professional photo and video production",
      "Creative concept development",
      "Content calendar planning",
      "Multi-platform optimization",
      "Brand guideline compliance"
    ],
    icon: Youtube,
    gradient: "from-red-500 to-pink-500"
  },
  {
    title: "Social Media Strategy",
    description: "Comprehensive social media strategies that amplify your brand across all platforms.",
    features: [
      "Platform-specific strategies",
      "Audience analysis and targeting",
      "Content pillar development",
      "Hashtag research and optimization",
      "Community management",
      "Growth hacking techniques"
    ],
    icon: MessageSquare,
    gradient: "from-blue-500 to-purple-500"
  },
  {
    title: "Live Streaming & Events",
    description: "Engaging live streaming campaigns and virtual events that drive real-time engagement.",
    features: [
      "Live streaming strategy",
      "Virtual event planning",
      "Real-time audience engagement",
      "Multi-platform broadcasting",
      "Interactive content creation",
      "Live analytics and optimization"
    ],
    icon: Twitch,
    gradient: "from-purple-500 to-indigo-500"
  }
];

const packages = [
  {
    name: "Starter",
    price: "$2,500",
    period: "/month",
    description: "Perfect for small businesses looking to dip their toes into influencer marketing.",
    features: [
      "Up to 5 micro-influencer partnerships",
      "Basic campaign strategy",
      "Monthly performance reports",
      "Email support",
      "1 platform focus"
    ],
    popular: false
  },
  {
    name: "Growth",
    price: "$7,500",
    period: "/month",
    description: "Ideal for growing brands ready to scale their influencer marketing efforts.",
    features: [
      "Up to 15 influencer partnerships",
      "Advanced campaign strategy",
      "Bi-weekly performance reports",
      "Priority support",
      "Multi-platform campaigns",
      "Content creation assistance",
      "Dedicated account manager"
    ],
    popular: true
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    description: "Comprehensive solutions for large brands with complex marketing needs.",
    features: [
      "Unlimited influencer partnerships",
      "Custom campaign strategies",
      "Real-time analytics dashboard",
      "24/7 support",
      "Full-service content creation",
      "Celebrity influencer access",
      "Dedicated team of specialists",
      "White-label reporting"
    ],
    popular: false
  }
];

export default function Services() {
  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 bg-clip-text text-transparent">
                Our Services
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Comprehensive influencer marketing solutions designed to amplify your brand and drive measurable results 
              across all social media platforms.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div key={index} className="bg-gray-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
                  <div className={`w-12 h-12 bg-gradient-to-r ${service.gradient} rounded-lg flex items-center justify-center mb-6`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  <ul className="space-y-3">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Package</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Flexible pricing options designed to grow with your business and marketing goals.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {packages.map((pkg, index) => (
              <div 
                key={index} 
                className={`bg-white rounded-2xl p-8 relative ${
                  pkg.popular 
                    ? 'border-2 border-purple-500 shadow-2xl scale-105' 
                    : 'border border-gray-200 shadow-lg'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <div className="mb-4">
                    <span className="text-4xl font-bold text-gray-900">{pkg.price}</span>
                    <span className="text-gray-600">{pkg.period}</span>
                  </div>
                  <p className="text-gray-600">{pkg.description}</p>
                </div>
                
                <ul className="space-y-4 mb-8">
                  {pkg.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Link
                  to="/contact"
                  className={`w-full py-3 px-4 rounded-lg font-semibold transition-colors flex items-center justify-center ${
                    pkg.popular
                      ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:shadow-lg'
                      : 'border-2 border-purple-600 text-purple-600 hover:bg-purple-600 hover:text-white'
                  }`}
                >
                  Get Started
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Process</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A proven methodology that ensures every campaign delivers exceptional results.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Strategy & Planning",
                description: "We analyze your brand, audience, and goals to create a tailored influencer marketing strategy."
              },
              {
                step: "02",
                title: "Influencer Matching",
                description: "Our team identifies and vets the perfect influencers who align with your brand values and audience."
              },
              {
                step: "03",
                title: "Campaign Execution",
                description: "We manage all aspects of campaign execution, from content creation to posting and engagement."
              },
              {
                step: "04",
                title: "Analytics & Optimization",
                description: "Real-time monitoring and optimization ensure maximum ROI and continuous improvement."
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-white font-bold text-lg">{item.step}</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Amplify Your Brand?
          </h2>
          <p className="text-xl text-purple-100 mb-8">
            Let's discuss how our services can help you achieve your marketing goals and drive real business results.
          </p>
          <Link
            to="/contact"
            className="bg-white text-purple-600 px-8 py-4 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 inline-flex items-center group"
          >
            Start Your Campaign
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </div>
  );
}
